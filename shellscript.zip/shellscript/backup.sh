#!/bin/bash

# Specify the directory you want to backup
backup_dir="/home/seed/Desktop/shellscript/test"

# Specify the directory where you want to store the backups
backup_dest="/home/seed/Desktop/shellscript/"

# Create a timestamp for the backup file
timestamp=$(date +%Y%m%d_%H%M%S)

# Create the backup file name
backup_file="backup_$timestamp.tar.gz"

# Create the backup
tar -czf "$backup_dest/$backup_file" "$backup_dir"/*

# Check if the backup was successful
if [ $? -eq 0 ]; then
  echo "Backup successful: $backup_dest/$backup_file"
else
  echo "Backup failed"
fi

