#!/bin/bash
# define shell interpreter  bash is bash shell; sh is bourne shell


# printing environment variables
echo  $USER
echo $PS1

#print user-defined variable

v1="I love programming!"
echo $v1
