#Program to Check Updates of the System
#!/bin/bash

echo -n "\n-------P4: Team Jensy------\n\n"

while true:
do echo -n "-----Update System at "; date;
echo "\n"
sudo apt update
sleep 120
done