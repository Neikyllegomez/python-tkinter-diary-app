#!/bin/bash

Directory=/home/seed/test

for test in "$Directory"/*; do
	cksum "$test"
	cksum "$test" >> cksum.txt
done 
