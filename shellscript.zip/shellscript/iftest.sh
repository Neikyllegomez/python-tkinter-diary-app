#!/bin/bash

x=10
y=14
if [ $x -lt $y ]
then
echo "Y is larger!"
else
echo "Y is not larger"
fi



