#! /bin/bash

echo Hostname is:
hostname

echo Showing Network of Host 

ifconfig
#ip addr show eth0
